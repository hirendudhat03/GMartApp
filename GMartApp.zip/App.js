//import React
import React from 'react';
import { View } from 'react-native';

//import File
import Splesh from './Source/Screen/splash';

const App = () => {

  return(
    <View style={{flex:1}}>

      <Splesh/>
    </View>
  );
}

export default App ;