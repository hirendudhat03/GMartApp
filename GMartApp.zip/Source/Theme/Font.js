export default {
    // Regular: 'JosefinSans-Regular',
    // Bold: 'JosefinSans-Bold',
    // Light: 'JosefinSans-Light',
    // SemiBold: 'JosefinSans-SemiBold',
    // Medium: 'JosefinSans-Medium',
  };
  