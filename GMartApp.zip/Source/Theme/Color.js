
export default {
    ColorRed : '#EF0000',
    ColorWhite : '#fff',
    ColorBlack : '#000',
    ColorDarkBlue : '#223263',
    ColorRed2 : '#EF0000',
    LightGray : '#9098B1',
    Gray : '#E0E0E0',
    ColorTab : '#0154a2',
    ColorGreen : '#2AA952',
};